package com.example.reportshilacases;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Device_Details extends AppCompatActivity  implements View.OnClickListener{
    private Button btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device__details);
        btn4=findViewById(R.id.button2);
        btn4.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        startActivity(new Intent(Device_Details.this,Location_Details.class));

    }
}