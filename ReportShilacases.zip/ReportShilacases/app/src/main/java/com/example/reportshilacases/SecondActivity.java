package com.example.reportshilacases;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener{
    private Button personal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        personal= findViewById(R.id.button6);


        personal.setOnClickListener(this);

    }



    @Override
    public void onClick(View v) {
        if (v== personal){
            startActivity(new Intent(SecondActivity.this,Personal_Info.class));
        }

    }
}