package com.example.reportshilacases;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Personal_Info extends AppCompatActivity  implements View.OnClickListener {
    private Button next2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal__info);
        next2= findViewById(R.id.button);

        next2.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v== next2){
            startActivity(new Intent(Personal_Info.this,Device_Details.class));
        }
    }
}